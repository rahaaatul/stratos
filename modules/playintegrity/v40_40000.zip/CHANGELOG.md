- Fixed some detections caused by Prop Spoofer WebUI

- Fixed some newly introduced lineageos props not getting spoofed on A17

- Fixed property detection in Hunter.

- Hide My Files can now hide a few more suspicious paths.

- Per-App Spoofing is back baby. You asked for it, so it's back.

- Autopilot also makes a return for the same reason.

- Added a built-in downloader for modules, APKs, and KPMs.

- Security patch spoofing has been bumped to August 2026.


- You can now update translations without updating the entire module.

- Added a toggle for the recommended ZN settings.

- Module Settings got a bit of a cleanup and should feel nicer to use.

- Spoofing configs are now backed up automatically during updates.

- Fixed OTA updates breaking on LineageOS.

- Fixed broken translations in sub-WebUIs.

- Improved module description indicators

- Updated HMA configuration.

- Added Spanish translation by @LeojGH.

- Added Arabic translation by @i3BSKA.

- Added Indonesian translation by @Nade-is-not-a-dev.

- Added Russian translation by Damima3369.

- Dropped Integrity Downloader action shell code.

- Dropped support for resetprop-rs.

- Dropped package.sh script.

- Cleaned up a bunch of internal code.

- Probably fixed a few things I forgot to write down. Who cares anyway? Life's short. I'm enjoying it & that's what really matters to me ;)