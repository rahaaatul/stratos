- Rebuilt Props Spoofer WebUI to automatically detect all known detection props, now it select the necessary fixes, and handle the entire process for you. All you have to do is to click the Fix button, and Integrity Box will take care of the rest automatically

- Updated autopilot backend

- Updated keybox script, fixed download errors

- Updated keybox path for TeeSim v4+

- Updated auto target scope to follow TeeSim v4+ JSON formatting

- Updated backup function to backup/restore support for TeeSim v4+

- Added ability to spoof build fields (device, model, manufacturer, patch, mode, Android) with latest Pixel Canary release props for TeeSim v4+

- Merged PR that fixes prop error (Thanks @incapdns)

- Added option to skip TeeSim config auto updater if needed (module settings > general)

- Dropped HMA config

- Dropped HMA backend script

- Dropped HMA injector from module settings UI ( Zygisk HMA OOS version doesn't support dirty config injection, manual import is required, so this feature is kinda useles ATM. Now you have to Download config via WebUI > Integrity Downloader > HMA Config)

- Dropped target simulator UI

- Dropped keybox import UI

- Fixed props not getting spoofed on some ROMs

- Disabled banner randomisation

- Updated Pixelify props

- Updated Legacy props

- Added ability to switch between Classic & Modern UI

- Added support for Modern UI layout

- Added UI backend script

- Updated Advanced Mode

- Cleaned up description from Advanced Mode

- Added info button to explain settings in Advanced Mode

- Updated Module Settings UI

- Cleaned up description from Module Settings

- Grouped rows in Module Settings

- Updated WebUI icon loading to use ksu://icon/ URI scheme

- Fixed app list loading using proper KSU exec commands

- Fixed system/user app filter using pm list packages

- Added Control Center-style dashboard layout

- Added script execution logging with per-script output

- Added popup toast notifications for script completion

- Fixed debug toggle state persistence

- Dropped SHA256 hash verification for downloaded modules

- Added per-module download log files

- Added Ploish translation by @StasGr12

- A lot of CSS modifications across all WebUIs which i am lazy to write