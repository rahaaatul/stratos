#!/system/bin/sh

HASH="/data/adb/modules/playintegrityfix/toolkit/modulehash"
MODULE_PROP="/data/adb/modules/playintegrityfix/module.prop"
STOCK_PROP="/data/adb/modules/playintegrityfix/toolkit/stock.prop"
LOG="/data/adb/Box-Brain/Integrity-Box-Logs/ResetID.log"

# Only run if KernelSU exists
#if [ ! -e "/data/adb/ksu" ] && [ ! -e "/data/adb/ksud" ]; then
#    exit 0
#fi

# Log
mkdir -p "$(dirname "$LOG")"
: > "$LOG"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"
}

log "Starting hash verification."

# Check required files
if [ ! -f "$HASH" ] || [ ! -f "$MODULE_PROP" ] || [ ! -f "$STOCK_PROP" ]; then
    log "Required file missing. Exiting."
    exit 0
fi

# Calculate SHA-256 hash
CURRENT_HASH=$(sha256sum "$MODULE_PROP" | awk '{print $1}')
EXPECTED_HASH=$(awk 'NF {print $1; exit}' "$HASH")

log "Current hash: $CURRENT_HASH"
log "Expected hash: $EXPECTED_HASH"

# Compare hashes
if [ "$CURRENT_HASH" = "$EXPECTED_HASH" ]; then
    log "Hash matches. Restoring stock.prop."

    if cp -f "$STOCK_PROP" "$MODULE_PROP"; then
        log "Successfully replaced module.prop."
    else
        log "Failed to replace module.prop."
    fi
else
    log "Hash mismatch. No changes made."
fi

log "Hash verification completed."