# shellcheck disable=SC2034
SKIPUNZIP=1

enforce_install_from_magisk_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Some recovery has broken implementations, install with such recovery will finally cause Riru or Riru modules not working"
    ui_print "! Please install from Magisk app"
    abort "*********************************************************"
  fi
}

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- LSPosed version ${VERSION}"

# Extract verify.sh
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"

# Base check
do_extract false "$ZIPFILE" 'customize.sh' "$TMPDIR"
do_extract false "$ZIPFILE" 'verify.sh' "$TMPDIR"
do_extract false "$ZIPFILE" 'util_functions.sh' "$TMPDIR"
. "$TMPDIR/util_functions.sh"
check_android_version
if [ -z "$APATCH" ] && [ -z "$KSU" ]; then
  check_magisk_version
fi
check_incompatible_module

enforce_install_from_magisk_app

# Check architecture
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x64" ] && [ "$ARCH" != "riscv64" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

rm -f /data/adb/lspd/manager.apk

# Extract libs
ui_print "- Extracting module files"

extract "machikado.$ARCH" "" "machikado"

mkdir -p "$MODPATH/zygisk"
mkdir -p "$MODPATH/lib"
mkdir -p "$MODPATH/bin"

ABI32=""
ABI64=""
if [ "$ARCH" = "arm" ]; then
  ABI32="armeabi-v7a"
  PRIMARY_ABI=$ABI32
elif [ "$ARCH" = "arm64" ]; then
  ABI32="armeabi-v7a"
  ABI64="arm64-v8a"
  PRIMARY_ABI=$ABI64
elif [ "$ARCH" = "x64" ]; then
  ABI64="x86_64"
  PRIMARY_ABI=$ABI64
elif [ "$ARCH" = "riscv64" ]; then
  ABI64="riscv64"
  PRIMARY_ABI=$ABI64
fi

extract 'module.prop'
extract 'action.sh'
extract 'service.sh'
extract 'emulated-soft-reboot.sh'
extract 'uninstall.sh'
extract 'sepolicy.rule'
extract 'zn_modules.txt'
extract 'framework.dex'
extract 'daemon.apk'
extract 'daemon'
extract 'lspd'
extract 'manager.apk'
extract "mazoku"
extract "package.pb"
extract "launcher.png"

ui_print "- Extracting libraries"

if [ -n "$ABI64" ]; then
  extract "lib/$ABI64/libframework.so" "zygisk" "$ABI64.so"
  extract "lib/$ABI64/libpreload.so" "lib" "libpreload64.so"
  extract "bin/$ABI64/dex2oat" "bin" "dex2oat64"
fi

if [ -n "$ABI32" ]; then
  extract "lib/$ABI32/libframework.so" "zygisk" "$ABI32.so"
  extract "lib/$ABI32/libpreload.so" "lib" "libpreload32.so"
  extract "bin/$ABI32/dex2oat" "bin" "dex2oat32"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 2000 0755 0755
if [ -n "$ABI64" ]; then
  set_perm "$MODPATH/bin/dex2oat64" 0 2000 0755 u:object_r:dex2oat_exec:s0
fi
if [ -n "$ABI32" ]; then
  set_perm "$MODPATH/bin/dex2oat32" 0 2000 0755 u:object_r:dex2oat_exec:s0
fi
chmod 0744 "$MODPATH/daemon"
chmod 0744 "$MODPATH/lspd"

ui_print "- Requesting license"
do_extract true "$ZIPFILE" "bin/$PRIMARY_ABI/sign_tool" "$TMPDIR"
chmod 0755 "$TMPDIR/sign_tool"
mkdir -p "/data/adb/lspd"

if [ ! -f "/data/adb/lspd/skip_online_request" ]; then
  "$TMPDIR/sign_tool" "-l" "$MODPATH/package.pb" "/data/adb/lspd/license.pb" 2>&1

  if [ $? -ne 0 ]; then
    ui_print "*********************************************************"
    ui_print "! Failed to request license"
    ui_print "! Please request another package from bot or try again later"
    ui_print "! For offline devices, unzip sign_tool and follow the usage"
    abort    "*********************************************************"
  fi
else
  ui_print "Skipped online request"
fi

ui_print "- Welcome to LSPosed!"
