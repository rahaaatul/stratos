MODDIR=${0%/*}

$MODDIR/lspd --stop
