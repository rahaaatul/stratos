#!/system/bin/sh

export TMP_PATH=/data/system/neozygisk

rm -rf $TMP_PATH
